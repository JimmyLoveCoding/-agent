"""
predict.py —— 用训练好的 GNN 预测晶体性质（兼 agent 的工具后端）
=========================================================
两种用法：
  1) 化学式预测：给化学式 -> 从 JARVIS 找结构 -> 预测（附 DFT 真值对照）
         python predict.py --formula GaN Si
  2) CIF 预测：给自己的 .cif 结构文件
         python predict.py a.cif b.cif

同时作为 agent 的工具后端，对外暴露 TOOL_SCHEMA / TOOL_FUNCS。
依赖：torch、numpy；方法 1 另需 jarvis-tools，方法 2 另需 pymatgen。
"""
import os

import numpy as np
import torch

import materials_db as db
from model import CrystalGNN
from dataset import graph_from_atoms, graph_from_structure, collate

HERE = os.path.dirname(os.path.abspath(__file__))
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_STRUCTURES = 20     # 一个化学式最多看几个结构

NOTE = ("prediction = GNN 模型预测（近似 DFT 值，非实验值）；"
        "dft_reference = 数据库 DFT 真值；split: train=训练时见过, test=没见过。"
        "单位：形成能/凸包 eV/atom，带隙 eV。")

_model = _ck = None


# ----------------------------------------------------------------------
# 模型加载与前向
# ----------------------------------------------------------------------
def load_model():
    ck = torch.load(os.path.join(HERE, "model.pt"), map_location=DEVICE, weights_only=False)
    model = CrystalGNN(n_tasks=ck["n_tasks"]).to(DEVICE)
    model.load_state_dict(ck["state_dict"])
    model.eval()
    return model, ck


def get_model():
    """进程内缓存的模型（agent 常驻进程只加载一次）。"""
    global _model, _ck
    if _model is None:
        _model, _ck = load_model()
    return _model, _ck


def predict_graphs(graphs, model, ck):
    """一批图 -> (B, 3) 预测值（已反标准化回原始单位）。"""
    for g in graphs:
        g["y"] = np.zeros(len(ck["targets"]), dtype=np.float32)   # collate 需要占位
    z, ei, ed, bt, n, _ = collate(graphs)
    with torch.no_grad():
        out = model(z.to(DEVICE), ei.to(DEVICE), ed.to(DEVICE), bt.to(DEVICE), n)
    return out.cpu().numpy() * ck["y_std"].numpy() + ck["y_mean"].numpy()


# ----------------------------------------------------------------------
# 方法 1：化学式预测（也是 agent 的工具）
# ----------------------------------------------------------------------
def predict_material_property(formula: str) -> dict:
    """化学式 -> 三性质预测（含数据库 DFT 参考值）。agent 工具 + 命令行共用。"""
    idxs = db.find(formula)
    if not idxs:
        return {"found": False, "formula": formula,
                "message": f"数据库中没有化学式 {formula}（只能查数据库已有的材料）。"}

    d = db.load()
    idxs = idxs[:MAX_STRUCTURES]
    graphs = [graph_from_atoms(d[i]["atoms"]) for i in idxs]
    model, ck = get_model()
    pred = predict_graphs(graphs, model, ck)

    results = []
    for k, i in enumerate(idxs):
        r = d[i]
        results.append({
            "jid": str(r.get("jid", "")),
            "split": db.which_split(str(r.get("formula", formula))),
            "prediction": {t: round(float(v), 4) for t, v in zip(ck["targets"], pred[k])},
            "dft_reference": {t: (None if v is None else round(float(v), 4))
                              for t, v in db.targets_of(r).items()},
        })
    return {"found": True, "formula": formula, "results": results, "note": NOTE}


# ----------------------------------------------------------------------
# 方法 2：CIF 预测
# ----------------------------------------------------------------------
def predict_cif_files(paths) -> list:
    """一批 .cif 文件 -> [{file, prediction}]。"""
    from pymatgen.core import Structure
    model, ck = get_model()
    graphs = [graph_from_structure(Structure.from_file(p)) for p in paths]
    pred = predict_graphs(graphs, model, ck)
    return [{"file": os.path.basename(p),
             "prediction": {t: round(float(v), 4) for t, v in zip(ck["targets"], row)}}
            for p, row in zip(paths, pred)]


# ----------------------------------------------------------------------
# agent 工具声明（给 LLM 看）
# ----------------------------------------------------------------------
TOOL_SCHEMA = [{
    "type": "function",
    "function": {
        "name": "predict_material_property",
        "description": (
            "查询一个材料的三种性质：形成能、带隙、稳定性（能量凸包）。"
            "输入化学式（如 GaN、Fe2O3），返回模型预测值与数据库 DFT 参考值。"
            "只能查 JARVIS-DFT 数据库里已有的材料，没有的会返回 found=false。"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "formula": {"type": "string", "description": "化学式，如 GaN、Fe2O3"},
            },
            "required": ["formula"],
        },
    },
}]

TOOL_FUNCS = {"predict_material_property": predict_material_property}


# ----------------------------------------------------------------------
# 命令行
# ----------------------------------------------------------------------
def _v(x):
    return f"{x:7.3f}" if x is not None else f"{'-':>7}"


def _show_formula(formulas):
    print(f"已加载 model.pt，设备：{DEVICE}")
    for w in formulas:
        res = predict_material_property(w)
        if not res["found"]:
            print(f"\n{w}: {res['message']}")
            continue
        print(f"\n{w}:")
        for r in res["results"]:
            p, t = r["prediction"], r["dft_reference"]
            print(f"  [{r['split']:5s}] {r['jid']:<13} "
                  f"FE {_v(t['formation_energy_per_atom'])}/{_v(p['formation_energy_per_atom'])}  "
                  f"GAP {_v(t['band_gap'])}/{_v(p['band_gap'])}  "
                  f"HULL {_v(t['energy_above_hull'])}/{_v(p['energy_above_hull'])}")


def main():
    import argparse
    ap = argparse.ArgumentParser(description="用训练好的 GNN 预测晶体性质")
    ap.add_argument("cif", nargs="*", help="一个或多个 .cif 文件（CIF 预测）")
    ap.add_argument("--formula", nargs="+", metavar="化学式", help="化学式（化学式预测）")
    args = ap.parse_args()

    if args.formula:
        _show_formula(args.formula)
    elif args.cif:
        print(f"已加载 model.pt，设备：{DEVICE}")
        for it in predict_cif_files(args.cif):
            print(f"\n{it['file']}")
            for name, v in it["prediction"].items():
                print(f"  {name:26s} = {v:.4f}")
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
