"""
materials_db.py —— JARVIS-DFT 数据访问（进程内缓存）
=========================================================
    load()        —— 加载 dft_3d 数据集（同一进程只加载一次）
    find()        —— 化学式 -> 条目索引
    targets_of()  —— 条目 -> 三性质真值
    split_sets()  —— 复刻训练时的成分分组划分（train / val）
    which_split() —— 某化学式属于 train / val / test
"""
import numpy as np

from dataset import num

# 我们的性质名 -> JARVIS 原始字段名
JARVIS_FIELDS = {
    "formation_energy_per_atom": "formation_energy_peratom",
    "band_gap": "optb88vdw_bandgap",
    "energy_above_hull": "ehull",
}

_cache = {}


def load():
    """加载 JARVIS dft_3d（进程内只加载一次；首次约 48MB 下载）。"""
    if "data" not in _cache:
        from jarvis.db.figshare import data as jdata
        print("加载 JARVIS dft_3d 数据集 ...", flush=True)
        _cache["data"] = jdata("dft_3d")
    return _cache["data"]


def targets_of(entry):
    """条目 -> {性质名: 真值}（缺失为 None）。"""
    return {t: num(entry.get(f)) for t, f in JARVIS_FIELDS.items()}


def find(formula):
    """化学式 -> 条目索引列表（大小写不敏感；查不到返回 []）。"""
    if "index" not in _cache:
        index = {}
        for i, r in enumerate(load()):
            f = str(r.get("formula", "")).strip().lower()
            index.setdefault(f, []).append(i)
        _cache["index"] = index
    return _cache["index"].get(str(formula).strip().lower(), [])


def split_sets():
    """按化学式分组的 train/val 划分（复刻训练时：同种子 42、同顺序）。

    用来判断某材料是"训练时见过"（train）还是"没见过"（val/test）。
    """
    if "splits" not in _cache:
        formulas = [r.get("formula", r.get("jid")) for r in load()
                    if all(v is not None for v in targets_of(r).values())]
        groups = np.array(sorted(set(formulas)))
        np.random.default_rng(42).shuffle(groups)
        m = len(groups)
        _cache["splits"] = (set(groups[:int(0.8 * m)]),
                            set(groups[int(0.8 * m):int(0.9 * m)]))
    return _cache["splits"]


def which_split(formula, g_tr=None, g_va=None):
    if g_tr is None:
        g_tr, g_va = split_sets()
    return "train" if formula in g_tr else ("val" if formula in g_va else "test")
